using System;


namespace Main
{
    public class Musteri
    {
        public int Id { get; set; }
        public string Name { get; set; }
            
        
    }
}
